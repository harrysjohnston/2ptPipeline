# coding: utf-8
import sys
sys.path.append('/share/splinter/hj/PhD/')
from functions import *

dd = read_files('wgp', idnot='cov*fine*z2*_b')
#dd['LA_b'] = np.loadtxt('./LAfit_lmstar_b')
dd['LA_r'] = np.loadtxt('./LAfit_lmstar_r')

handles = []

#f, (ax1, ax2) = plt.subplots(2, 1, sharex=True, figsize=(10, 8))
f, axs = plt.subplots(figsize=(10, 7))
ax1 = ax2 = axs

for k in dd.keys():
	if k.startswith('LA'): continue
	label = {'wgp_b':'GAMA blue', 'wgp_r':'GAMA red', 'wgp_lmstar_b':'$M_{*}>10^{11}M_{\odot}$, blue', 'wgp_lmstar_r':'$M_{*}>10^{11}M_{\odot}$, red'}[k]
	#fmt = {'wgp_b':'bo-', 'wgp_r':'ro-', 'wgp_lmstar_b':'bx:', 'wgp_lmstar_r':'rx:'}[k]
	fmt = {'wgp_b':'bo', 'wgp_r':'ro', 'wgp_lmstar_b':'b*', 'wgp_lmstar_r':'r*'}[k]
	mfc = {'wgp_b':'none', 'wgp_r':'none', 'wgp_lmstar_b':'b', 'wgp_lmstar_r':'r'}[k]
	#mfc = 'face'
	ms = {'wgp_b':6, 'wgp_r':6, 'wgp_lmstar_b':7, 'wgp_lmstar_r':7}[k]
	#s = {'wgp_b':0.96, 'wgp_lmstar_b':0.99, 'wgp_r':1.02, 'wgp_lmstar_r':1.03}[k]
	lw = {'wgp_b':1.3, 'wgp_r':1.3, 'wgp_lmstar_b':1, 'wgp_lmstar_r':1}[k]
	#lw = 1
	cs = 3
	rpp = 0.7
	s = (0.98, 1.02)['lmstar' in k]
	ax = (ax1, ax2)[k.endswith('r')]
	rp, w, bt, err = dd[k].T[:4]
	eb = ax.errorbar(rp*s, rp**rpp * w, yerr=rp**rpp * err, fmt=fmt, mfc=mfc, ms=ms, lw=lw, capsize=cs, label=label)
	if k in ['wgp_r', 'wgp_b']:
		eb[-1][0].set_linestyle(':')
	if k in ['wgp_r', 'wgp_lmstar_r']:
		handles.append(eb)

for k in ['LA_b', 'LA_r']:
	if k == 'LA_b': continue
	ax = (ax1, ax2)[k.endswith('r')]
	fmt = {'LA_b':'b-', 'LA_r':'r-'}[k]
	rp, w = dd[k].T
	rp, w = rp[(rp >= 0.2)], w[(rp >= 0.2)]
	rp *= 1.02
	lin = (rp >= 6.) & (rp <= 35.)
	nlin = rp <= 6.
	ax.plot(rp[lin], rp[lin]**rpp * w[lin], fmt, lw=1.2)
	ax.plot(rp[nlin], rp[nlin]**rpp * w[nlin], c='grey', lw=0.8)
	ax.plot(rp[rp >= 35.], rp[rp >= 35.]**rpp * w[rp >= 35.], c='grey', lw=0.8)

for ax in (ax1, ax2):
	ax.legend(ncol=2, loc='best', fontsize=16)
	ax.set_xscale('log')
	ax.set_xlim(0.1, 60.)
	ax.axhline(0, c='k', lw=0.7)
	ax.axvspan(0., 6., color='grey', alpha=0.2, lw=0)
	ax.axvspan(35., 60., color='grey', alpha=0.2, lw=0)

#for h in handles:
#	for hh in h:
#		if hasattr(hh, '__iter__'):
#			for hhh in hh:
#				hhh.set_color('grey')
#		else:
#			hh.set_color('grey')
#ax2.legend(handles, ['GAMA', '$M_{*}>10^{11}M_{\odot}$'], ncol=2, fontsize=16, loc='best')

#ax1.set_ylim(-1.5, 2.5)
ax1.set_ylim(-0.5, 1.8)
ax2.set_xlabel('$r_{p}$ [$h^{-1}Mpc$]', fontsize=22)
f.text(0.005, 0.54, r'$r_{p}^{0.7}w_{\rm{g}+}$ [$h^{-1}Mpc$]$^{1.7}$', va='center', rotation='vertical', fontsize=22)
plt.tight_layout(pad=3.3)
plt.subplots_adjust(hspace=0)
plt.savefig('./lmstar_plot.png', bbox_inches='tight')
plt.savefig('./lmstar_plot.pdf', bbox_inches='tight')
plt.show()







